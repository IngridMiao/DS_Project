package com.example.dsfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.dsfinal")
public class GoogleOnWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoogleOnWebApplication.class, args);
	}

}
