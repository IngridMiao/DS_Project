package com.example.dsfinal.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SearchBetterService {
    
    @Autowired
    private GoogleQueryService googleQueryService;
    public List<WebPage> performSearch(String searchKeyword) throws IOException {
        
        // 1. 執行 Google 查詢
        HashMap<String, String> searchResults = googleQueryService.query(searchKeyword);

        // 2. 創建 WebPage 對象列表
        List<WebPage> webPages = new ArrayList<>();
        for (Map.Entry<String, String> entry : searchResults.entrySet()) {
            WebPage page = new WebPage(entry.getValue(), entry.getKey());
            webPages.add(page);
        }
       
        // 3. 創建 WebTree 並計算分數
        WebTree webTree = new WebTree(webPages.get(0));
        for (int i = 1; i < webPages.size(); i++) {
            webTree.root.addChild(new WebNode(webPages.get(i)));
        }
        webTree.setPostOrderScore();

        // 4. 使用 WebPageHeap 排序結果
        WebPageHeap heap = new WebPageHeap(2.8);
        heap.buildHeap(webTree);

        // 5. 提取排序好的結果
        List<WebPage> bestResults = new ArrayList<>();
        WebNode node;
        while ((node = heap.getTopNode()) != null) {
            bestResults.add(node.webPage);
        }

        return bestResults;
    }
}

