package com.example.dsfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
